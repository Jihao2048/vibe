# -*- coding: utf-8 -*-
"""
no_subpixel.py -- 无亚像素重采样核心引擎

设计目标
--------
普通图片查看器在缩放时会做双线性 / 双三次插值, 于是屏幕上会出现
"半个像素" 的中间色 -- 这就是亚像素(子像素)渲染。

本模块保证输出图像中每一个绘制出来的像素都严格等于源图上某一个
真实存在的像素(或由整数个完整源像素块经整数倍盒式平均得到),
绝不产生插值出来的颜色。

两种模式
--------
1. "nearest"  -- 最近邻
   输出像素 = 源图某个真实像素, 逐位相同。100% 无亚像素。

2. "block"    -- 整数块盒式平均(保真降采样)
   源图被切成 k x k 的整块(k 为整数), 每个输出像素是整块内
   所有完整源像素的算术平均。它仍然是"完整像素的整数组合",
   不存在半个像素的采样权重, 所以依然是无亚像素的,
   同时避免了最近邻在大幅缩小时产生的锯齿与摩尔纹。

缩放倍率的量化
--------------
用户请求的缩放倍率 z 会被量化到允许集合:
  * 放大 (z >= 1): 只允许整数倍 1, 2, 3, ...
  * 缩小 (z < 1) : 只允许 1/2, 1/3, 1/4, ... (即 k 为整数)
介于两者之间的任意倍率会吸附到最近的合法倍率, 因此永远不会
出现 "1.37 倍" 这种必然引入亚像素的缩放。
"""

from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np
from PIL import Image

__all__ = [
    "quantize_zoom",
    "zoom_candidates",
    "plan_scale",
    "resize_no_subpixel",
    "resize_nearest",
    "resize_block",
    "check_no_subpixel",
    "ScalePlan",
]


# --------------------------------------------------------------------------
# 缩放倍率量化
# --------------------------------------------------------------------------

def zoom_candidates(limit: int = 32) -> Tuple[float, ...]:
    """返回允许的缩放倍率集合(升序)。

    缩小: 1/limit ... 1/2
    放大: 1, 2 ... limit
    """
    downs = [1.0 / k for k in range(limit, 1, -1)]
    ups = [float(k) for k in range(1, limit + 1)]
    return tuple(downs + ups)


def quantize_zoom(zoom: float, limit: int = 32) -> float:
    """把任意倍率吸附到最近的合法倍率。

    合法倍率 = {1/n} ∪ {n}, n 为正整数。
    做对数距离比较, 保证 0.5x 与 2x 在视觉上"等距"。
    """
    if not math.isfinite(zoom) or zoom <= 0:
        raise ValueError("zoom 必须是正的有限数, 收到: %r" % (zoom,))

    best = None
    best_dist = None
    for cand in zoom_candidates(limit):
        # 对数域距离: |ln(z) - ln(cand)|
        dist = abs(math.log(zoom) - math.log(cand))
        if best_dist is None or dist < best_dist:
            best_dist = dist
            best = cand
    return float(best)


# --------------------------------------------------------------------------
# 缩放方案
# --------------------------------------------------------------------------

class ScalePlan(object):
    """描述一次无亚像素缩放将如何执行。"""

    __slots__ = (
        "src_w", "src_h", "dst_w", "dst_h",
        "factor", "kind", "requested_zoom",
        "cropped", "crop_box",
    )

    def __init__(self, src_w, src_h, dst_w, dst_h, factor, kind,
                 requested_zoom, cropped, crop_box):
        self.src_w = src_w
        self.src_h = src_h
        self.dst_w = dst_w
        self.dst_h = dst_h
        self.factor = factor          # 整数倍率 (放大=倍数, 缩小=块边长)
        self.kind = kind              # "up" | "down" | "same"
        self.requested_zoom = requested_zoom
        self.cropped = cropped        # 为凑整数块而裁掉的像素数
        self.crop_box = crop_box      # (left, top, right, bottom) 或 None

    @property
    def effective_zoom(self) -> float:
        if self.kind == "up":
            return float(self.factor)
        if self.kind == "down":
            return 1.0 / float(self.factor)
        return 1.0

    def __repr__(self) -> str:
        return (
            "ScalePlan(src=%dx%d -> dst=%dx%d, kind=%s, factor=%d, "
            "zoom=%.4f, cropped=%d)"
            % (self.src_w, self.src_h, self.dst_w, self.dst_h,
               self.kind, self.factor, self.effective_zoom, self.cropped)
        )


def plan_scale(src_w: int, src_h: int, zoom: float,
               limit: int = 32, allow_crop: bool = True) -> ScalePlan:
    """把 (源尺寸, 期望倍率) 规划成一次严格无亚像素的缩放。

    allow_crop=True 时, 为了让尺寸能被整数块整除, 允许从右侧/底部
    裁掉少量像素(最多 k-1 个)。这比拉伸到非整数尺寸更忠于原图。
    """
    if src_w <= 0 or src_h <= 0:
        raise ValueError("源尺寸必须为正")

    z = quantize_zoom(zoom, limit=limit)

    if z >= 1.0:
        k = int(round(z))
        k = max(1, k)
        return ScalePlan(src_w, src_h, src_w * k, src_h * k, k, "up",
                         zoom, 0, None)

    # 缩小: k 为整数块边长
    k = int(round(1.0 / z))
    k = max(2, k)

    cropped = 0
    crop_box = None
    if allow_crop:
        new_w = src_w - (src_w % k)
        new_h = src_h - (src_h % k)
        # 至少保留一块
        if new_w < k:
            new_w = k
        if new_h < k:
            new_h = k
        if new_w != src_w or new_h != src_h:
            crop_box = (0, 0, new_w, new_h)
            cropped = (src_w - new_w) * (src_h - new_h) and \
                      (src_w * src_h - new_w * new_h)
        dst_w = new_w // k
        dst_h = new_h // k
        src_used_w, src_used_h = new_w, new_h
    else:
        # 不允许裁剪: 用向上取整的块数, 边缘块会被补齐(与边界像素夹取)
        dst_w = max(1, int(math.ceil(src_w / float(k))))
        dst_h = max(1, int(math.ceil(src_h / float(k))))
        src_used_w, src_used_h = dst_w * k, dst_h * k

    return ScalePlan(src_used_w, src_used_h, dst_w, dst_h, k, "down",
                     zoom, cropped, crop_box)


# --------------------------------------------------------------------------
# 实际重采样
# --------------------------------------------------------------------------

def _as_array(img: Image.Image) -> np.ndarray:
    """转成 (H, W) 或 (H, W, C) 的 float64 数组。

    统一升到 float64 只是为了让块平均有足够精度, 输入数值本身
    全部来自源图的真实像素, 没有任何插值权重。
    """
    if img.mode in ("P", "PA"):
        img = img.convert("RGBA" if "A" in img.mode else "RGB")
    return np.asarray(img, dtype=np.float64)


def _from_array(arr: np.ndarray, mode: str = None) -> Image.Image:
    """把 float 数组还原成 PIL 图像(四舍五入到 uint8)。

    mode 仅在 numpy 无法推断时作为兜底传入; Pillow 11+ 建议省略 mode。
    """
    out = np.clip(np.rint(arr), 0, 255).astype(np.uint8)
    try:
        return Image.fromarray(out)          # Pillow 自行推断 mode
    except Exception:
        return Image.fromarray(out, mode=mode)


def resize_nearest(img: Image.Image, zoom: float, limit: int = 32) -> Image.Image:
    """最近邻放大/缩小。每个输出像素都是源图真实像素的逐位拷贝。"""
    plan = plan_scale(img.width, img.height, zoom, limit=limit)
    if plan.crop_box is not None:
        img = img.crop(plan.crop_box)

    if plan.kind == "up":
        k = plan.factor
        # np.repeat 是整数倍复制, 不引入任何新数值
        arr = _as_array(img)
        arr = np.repeat(np.repeat(arr, k, axis=0), k, axis=1)
        return _from_array(arr, img.mode)

    # 缩小也要无亚像素: 直接取每块左上角像素(nearest 语义)
    k = plan.factor
    arr = _as_array(img)
    h = (arr.shape[0] // k) * k
    w = (arr.shape[1] // k) * k
    arr = arr[:h, :w]
    if arr.ndim == 2:
        arr = arr[::k, ::k]
    else:
        arr = arr[::k, ::k, :]
    return _from_array(arr, img.mode)


def resize_block(img: Image.Image, zoom: float, limit: int = 32) -> Image.Image:
    """整数块盒式重采样。

    放大时退化为最近邻(整数倍复制);
    缩小时每个输出像素 = k x k 完整源像素块的均值。
    """
    plan = plan_scale(img.width, img.height, zoom, limit=limit)
    if plan.crop_box is not None:
        img = img.crop(plan.crop_box)

    arr = _as_array(img)

    if plan.kind == "up":
        k = plan.factor
        arr = np.repeat(np.repeat(arr, k, axis=0), k, axis=1)
        return _from_array(arr, img.mode)

    k = plan.factor
    h = (arr.shape[0] // k) * k
    w = (arr.shape[1] // k) * k
    arr = arr[:h, :w]

    # 整形 + 沿块内轴求均值 —— 块内包含且仅包含完整像素
    if arr.ndim == 2:
        arr = arr.reshape(h // k, k, w // k, k).mean(axis=(1, 3))
    else:
        arr = arr.reshape(h // k, k, w // k, k, arr.shape[2]).mean(axis=(1, 3))
    return _from_array(arr, img.mode)


def resize_no_subpixel(img: Image.Image, zoom: float,
                       method: str = "block",
                       limit: int = 32) -> Image.Image:
    """统一入口。

    method:
      "block"   -- 整数块盒式(推荐, 缩小时无锯齿)
      "nearest" -- 最近邻(放大时最"纯净")
    """
    if method == "nearest":
        return resize_nearest(img, zoom, limit=limit)
    if method == "block":
        return resize_block(img, zoom, limit=limit)
    raise ValueError("未知 method: %r (可选 'block' / 'nearest')" % (method,))


# --------------------------------------------------------------------------
# 自检: 证明输出确实无亚像素
# --------------------------------------------------------------------------

def check_no_subpixel(src: Image.Image, dst: Image.Image,
                      method: str = "block") -> dict:
    """验证 dst 的每个像素都来自 src 的完整像素(整数块)。

    判据:
      1. 放大情形: dst 中每个颜色值必须能在 src 中找到逐位相同的像素。
         更强: dst 由 src 做整数倍 repeat 得到, 逐块完全相同。
      2. 缩小情形: dst 中每个像素等于 src 中某个 k x k 完整块的均值。
         不存在"半个像素"的权重点。

    返回一个报告 dict, ok 字段表示是否通过。
    """
    s = _as_array(src)
    d = _as_array(dst)

    report = {
        "src_size": (src.width, src.height),
        "dst_size": (dst.width, dst.height),
        "method": method,
        "max_abs_diff": None,
        "ok": False,
        "reason": "",
    }

    # 放大倍率 = 输出 / 源; 缩小倍率 = 源 / 输出。二者都在整数关系下才无亚像素。
    up_w, up_h = dst.width / float(src.width), dst.height / float(src.height)
    dn_w, dn_h = src.width / float(dst.width), src.height / float(dst.height)

    def _is_int(x):
        return abs(x - round(x)) < 1e-9

    up_ok = _is_int(up_w) and _is_int(up_h) and up_w >= 1.0 and up_h >= 1.0
    dn_ok = _is_int(dn_w) and _is_int(dn_h) and dn_w >= 1.0 and dn_h >= 1.0

    if not (up_ok or dn_ok):
        report["reason"] = (
            "尺寸比不是整数 (放大 %.4f x %.4f / 缩小 %.4f x %.4f), "
            "必然包含亚像素采样"
            % (up_w, up_h, dn_w, dn_h)
        )
        return report

    # ---- 情形 A: 整数倍放大, 输出必须是源像素的逐块精确复制 ----
    if up_ok:
        kw, kh = int(round(up_w)), int(round(up_h))
        if kw == 1 and kh == 1:
            report["max_abs_diff"] = float(np.max(np.abs(s - d)))
            report["ok"] = bool(np.array_equal(s, d))
            report["reason"] = "1:1 直接拷贝, 无缩放"
            return report

        # 还原成源尺寸后必须与源逐位相同
        reduced = d[::kh, ::kw]
        if reduced.shape[:2] != s.shape[:2]:
            report["reason"] = "放大后还原尺寸与源不符"
            return report
        diff = np.abs(reduced.astype(np.int64) - s.astype(np.int64))
        report["max_abs_diff"] = float(np.max(diff))
        report["ok"] = bool(np.array_equal(reduced, s))
        report["block"] = (kh, kw)
        report["reason"] = (
            "每个输出像素都是源图中真实存在的像素, %dx%d 块内完全相同, "
            "无插值中间色" % (kh, kw)
        )
        if method not in ("block", "nearest"):
            report["reason"] += " (注意: method=%s, 此处为采样点恰好重合)" % method
        return report

    # ---- 情形 B: 整数块缩小, 输出必须是完整块的均值 ----
    kw, kh = int(round(dn_w)), int(round(dn_h))
    h = (s.shape[0] // kh) * kh
    w = (s.shape[1] // kw) * kw
    s2 = s[:h, :w]

    if s2.ndim == 2:
        means = s2.reshape(h // kh, kh, w // kw, kw).mean(axis=(1, 3))
    else:
        means = s2.reshape(h // kh, kh, w // kw, kw, s2.shape[2]).mean(axis=(1, 3))

    if d.shape[:2] != means.shape[:2]:
        report["reason"] = "输出尺寸与块均值尺寸不符"
        return report

    if method == "nearest":
        # 最近邻缩小: 每个输出像素 = 对应块左上角的那个真实像素
        expected = s2[::kh, ::kw]
        if d.shape[:2] != expected.shape[:2]:
            report["reason"] = "输出尺寸与最近邻取样尺寸不符"
            return report
        diff = np.abs(expected.astype(np.int64) - d.astype(np.int64))
        report["max_abs_diff"] = float(np.max(diff))
        report["ok"] = bool(np.array_equal(expected, d))
        report["block"] = (kh, kw)
        report["reason"] = (
            "每个输出像素 = 源图中真实存在的像素(块左上角), 无插值中间色"
        )
        return report

    diff = np.abs(means - d)
    report["max_abs_diff"] = float(np.max(diff))
    # 允许半个量化单位(uint8 四舍五入误差)
    report["ok"] = bool(np.max(diff) <= 0.5 + 1e-9)
    report["block"] = (kh, kw)
    report["reason"] = (
        "每个输出像素 = %dx%d 完整源像素块的均值, 无半像素权重" % (kh, kw)
    )
    return report
