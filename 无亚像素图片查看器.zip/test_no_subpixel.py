# -*- coding: utf-8 -*-
"""
test_no_subpixel.py -- 无亚像素引擎的完整测试套件

不依赖 pytest, 直接 python test_no_subpixel.py 即可运行。
"""

from __future__ import annotations

import io
import os
import sys
import time
import traceback

import numpy as np
from PIL import Image

import no_subpixel as ns

_results = []


def check(name, cond, detail=""):
    _results.append((name, bool(cond), detail))
    return bool(cond)


def make_img(w=37, h=23, mode="RGB"):
    rng = np.random.default_rng(1234)
    if mode == "L":
        a = rng.integers(0, 256, size=(h, w), dtype=np.uint8)
    else:
        a = rng.integers(0, 256, size=(h, w, 3), dtype=np.uint8)
    return Image.fromarray(a)


# ----------------------------------------------------------------------
# 1. 倍率量化
# ----------------------------------------------------------------------
def test_quantize():
    cases = [
        (1.0, 1.0), (1.0001, 1.0), (1.4, 1.0), (1.45, 2.0), (1.9, 2.0),
        (2.0, 2.0), (3.7, 4.0), (0.99, 1.0), (0.51, 0.5), (0.5, 0.5),
        (0.34, 1.0 / 3), (0.2, 0.2), (0.001, 1.0 / 32),
    ]
    for z, want in cases:
        got = ns.quantize_zoom(z)
        check("quantize(%.4f)==%.4f" % (z, want), abs(got - want) < 1e-9,
              "得到 %.6f" % got)

    # 量化结果必须永远是合法档位
    ok = True
    for z in np.linspace(0.02, 40, 500):
        q = ns.quantize_zoom(float(z))
        if q not in ns.zoom_candidates(32):
            ok = False
            break
    check("量化结果始终落在合法集合内", ok)

    # 非法输入必须抛错
    for bad in (0, -1, float("nan"), float("inf")):
        try:
            ns.quantize_zoom(bad)
            check("quantize 拒绝 %r" % bad, False, "未抛异常")
        except ValueError:
            check("quantize 拒绝 %r" % bad, True)


# ----------------------------------------------------------------------
# 2. 缩放方案
# ----------------------------------------------------------------------
def test_plan():
    p = ns.plan_scale(100, 60, 4.0)
    check("放大方案尺寸", (p.dst_w, p.dst_h) == (400, 240))
    check("放大方案 factor", p.factor == 4 and p.kind == "up")

    p = ns.plan_scale(100, 60, 0.25)
    check("缩小方案尺寸", (p.dst_w, p.dst_h) == (25, 15))
    check("缩小方案 factor", p.factor == 4 and p.kind == "down")

    # 质数尺寸 + 缩小: 必须能整除
    for w in (37, 23, 101, 7):
        for h in (19, 5, 97, 3):
            for z in (0.5, 1/3, 0.25, 0.2, 1/7):
                p = ns.plan_scale(w, h, z)
                k = p.factor
                check("质数尺寸 %dx%d @%.3f 可整除" % (w, h, z),
                      p.src_w % k == 0 and p.src_h % k == 0,
                      "src=%dx%d k=%d" % (p.src_w, p.src_h, k))
                check("质数尺寸 %dx%d @%.3f 商正确" % (w, h, z),
                      p.dst_w == p.src_w // k and p.dst_h == p.src_h // k)

    # 不允许裁剪时必须补齐到整数块
    p = ns.plan_scale(37, 23, 0.25, allow_crop=False)
    check("allow_crop=False 时尺寸取整块", p.src_w % p.factor == 0)


# ----------------------------------------------------------------------
# 3. 无亚像素性质(核心)
# ----------------------------------------------------------------------
def test_nosubpixel_property():
    for mode in ("RGB", "L"):
        for size in ((37, 23), (64, 64), (13, 41), (1, 1), (5, 1)):
            img = make_img(size[0], size[1], mode)
            for method in ("block", "nearest"):
                for z in (8.0, 4.0, 3.0, 2.0, 1.0, 0.5, 1/3, 0.25, 0.2, 1/7):
                    tag = "%s %dx%d %s %.4f" % (mode, size[0], size[1],
                                                method, z)
                    try:
                        plan = ns.plan_scale(img.width, img.height, z)
                        out = ns.resize_no_subpixel(img, z, method=method)
                        base = img.crop(plan.crop_box) if plan.crop_box else img
                        rep = ns.check_no_subpixel(base, out, method=method)
                        check("自检通过 " + tag, rep["ok"], str(rep.get("reason")))
                    except Exception as e:
                        check("自检通过 " + tag, False,
                              "%s: %s" % (type(e).__name__, e))


def test_exact_block_values():
    """更严格的逐点验证: 放大时输出块内必须逐位等于源像素。"""
    img = make_img(31, 17)
    a = np.asarray(img)
    for k in (2, 3, 5, 8):
        out = ns.resize_no_subpixel(img, float(k), method="block")
        b = np.asarray(out)
        check("放大 %dx 尺寸正确" % k, b.shape[:2] == (17 * k, 31 * k))
        check("放大 %dx 逐位等于源" % k,
              np.array_equal(b[::k, ::k], a) and
              np.array_equal(b.reshape(17, k, 31, k, 3)[:, 0, :, 0], a))

    # 缩小时输出必须 = 完整块均值
    for k in (2, 3, 5):
        out = ns.resize_no_subpixel(img, 1.0 / k, method="block")
        b = np.asarray(out).astype(np.float64)
        w = (31 // k) * k
        h = (17 // k) * k
        expect = a[:h, :w].reshape(h // k, k, w // k, k, 3).mean(axis=(1, 3))
        check("缩小 1/%d 等于块均值" % k, np.max(np.abs(expect - b)) <= 0.5)


def test_no_intermediate_colors():
    """关键判据: 输出的每个颜色值必须能在源图中找到(放大时)。"""
    img = make_img(29, 19)
    src_colors = set(map(tuple, np.asarray(img).reshape(-1, 3).tolist()))
    for k in (2, 4, 7):
        out = np.asarray(ns.resize_no_subpixel(img, float(k), method="block"))
        out_colors = set(map(tuple, out.reshape(-1, 3).tolist()))
        check("放大 %dx 未产生新颜色" % k, out_colors <= src_colors,
              "多出 %d 种" % len(out_colors - src_colors))


def test_reject_interpolated():
    """对照组: 双线性/双三次/非整数倍必须被判定为含亚像素。"""
    img = make_img(40, 30)
    bad = 0
    for filt, nm in ((Image.BILINEAR, "bilinear"), (Image.BICUBIC, "bicubic"),
                     (Image.LANCZOS, "lanczos")):
        for size in ((137, 91), (61, 43), (100, 77)):
            out = img.resize(size, filt)
            rep = ns.check_no_subpixel(img, out, method=nm)
            if rep["ok"]:
                bad += 1
                check("正确拒绝 %s -> %s" % (nm, size), False, "被误判为通过")
    check("插值方法全部被拒绝", bad == 0)


def test_alpha_preserved():
    """RGBA 图必须保持 4 通道。"""
    a = np.zeros((20, 20, 4), dtype=np.uint8)
    a[..., 3] = np.arange(20)[:, None] * 12
    img = Image.fromarray(a)
    out = ns.resize_no_subpixel(img, 2.0, method="block")
    check("RGBA 放大保持 4 通道", out.mode == "RGBA" and
          np.asarray(out).shape[2] == 4)
    out2 = ns.resize_no_subpixel(img, 0.5, method="block")
    check("RGBA 缩小保持 4 通道", out2.mode == "RGBA" and
          np.asarray(out2).shape[2] == 4)


def test_idempotent_zoom():
    """1.0x 必须是逐位相同的拷贝。"""
    img = make_img(33, 21)
    out = ns.resize_no_subpixel(img, 1.0, method="block")
    check("1.0x 逐位相同", np.array_equal(np.asarray(img), np.asarray(out)))


def test_unknown_method():
    try:
        ns.resize_no_subpixel(make_img(), 2.0, method="magic")
        check("未知 method 抛错", False, "未抛异常")
    except ValueError:
        check("未知 method 抛错", True)


# ----------------------------------------------------------------------
# 10. DPI / 显示链路: 屏幕缩放不能把画面糊掉
# ----------------------------------------------------------------------
def test_dpi_module():
    """dpi_win 必须能正确报出缩放比, 且感知声明成功。"""
    import dpi_win
    e = dpi_win.describe_environment()
    check("dpi_win 报告了 DPI", e["dpi"] > 0, str(e))
    check("dpi_win 缩放比自洽",
          abs(e["scale"] - e["dpi"] / 96.0) < 1e-9, str(e["scale"]))
    if sys.platform.startswith("win"):
        check("Windows 上 DPI 感知声明成功", e["ok"],
              "awareness=%s" % e["awareness"])
        # 感知成功时, 系统 DPI 应等于真实 DPI(不被虚拟化成 96)
        check("DPI 未被虚拟化", e["dpi"] >= 96, str(e["dpi"]))


def test_tk_scaling_forced():
    """Tk 的 scaling 必须被压到 1.0, 否则图像会被非整数倍摆放。"""
    if not sys.platform.startswith("win"):
        return
    try:
        import tkinter as tk
        import dpi_win
        dpi_win.enable_dpi_awareness()
        root = tk.Tk()
        root.withdraw()
        root.tk.call("tk", "scaling", 1.0)
        s = float(root.tk.call("tk", "scaling"))
        root.destroy()
        check("tk scaling 可被强制为 1.0", abs(s - 1.0) < 0.01,
              "scaling=%.4f" % s)
    except Exception as e:
        check("tk scaling 测试", False, "%s: %s" % (type(e).__name__, e))


def test_screen_readback():
    """终极验证: 从屏幕帧缓冲读回像素, 必须没有插值中间色。

    这是唯一能证明"显示链路末端无亚像素"的方法。需要 GUI 环境。
    """
    if not sys.platform.startswith("win"):
        return
    if os.environ.get("NO_SCREEN_TEST"):
        return
    import subprocess
    import tempfile
    here = os.path.dirname(os.path.abspath(__file__))
    script = os.path.join(here, "verify_display.py")
    if not os.path.exists(script):
        return
    # 注意: 某些沙箱禁止父进程通过管道捕获子进程输出。
    # 因此让子进程把结论写进文件, 父进程只读文件。
    fd, resfile = tempfile.mkstemp(prefix="readback_", suffix=".txt")
    os.close(fd)
    try:
        with open(resfile, "wb") as sink:
            p = subprocess.run([sys.executable, script, "--result", resfile],
                               cwd=here, stdout=sink, stderr=subprocess.STDOUT,
                               timeout=180)
        with open(resfile, "r", encoding="utf-8", errors="replace") as f:
            txt = f.read()
        check("屏幕读回无插值中间色", p.returncode == 0,
              txt.strip()[-300:])
    except Exception as e:
        check("屏幕读回测试", False, "%s: %s" % (type(e).__name__, e))
    finally:
        try:
            os.remove(resfile)
        except OSError:
            pass


# ----------------------------------------------------------------------
# 11. 性能: 重绘耗时不能随倍率增长
# ----------------------------------------------------------------------
def _viewport_render(base, plan, method, vx, vy, vw, vh):
    """与 viewer._render_viewport 相同的坐标约定(用于等价性测试)。"""
    k = plan.factor
    if plan.kind == "up":
        sx0 = max(0, vx // k); sy0 = max(0, vy // k)
        sx1 = min(base.width, -(-(vx + vw) // k))
        sy1 = min(base.height, -(-(vy + vh) // k))
        box = (sx0, sy0, sx1, sy1)
        ox, oy = sx0 * k, sy0 * k
    else:
        sx0 = max(0, vx); sy0 = max(0, vy)
        sx1 = min(base.width // k, vx + vw)
        sy1 = min(base.height // k, vy + vh)
        box = (sx0 * k, sy0 * k, sx1 * k, sy1 * k)
        ox, oy = sx0, sy0
    if box[2] <= box[0] or box[3] <= box[1]:
        return None, (0, 0)
    out = ns.resize_no_subpixel(base.crop(box), plan.effective_zoom,
                                method=method)
    return np.asarray(out), (ox, oy)


def test_viewport_equals_full():
    """视口渲染必须与整幅渲染逐像素一致(这是性能优化的正确性前提)。"""
    rng = np.random.default_rng(3)
    bad = 0
    total = 0
    for (W, H) in ((160, 100), (37, 23), (180, 120)):
        img = Image.fromarray(
            rng.integers(0, 256, size=(H, W, 3), dtype=np.uint8))
        for z in (1.0, 2.0, 3.0, 8.0, 0.5, 1 / 3, 0.25):
            plan = ns.plan_scale(W, H, z)
            base = img.crop(plan.crop_box) if plan.crop_box else img
            for method in ("block", "nearest"):
                full = np.asarray(ns.resize_no_subpixel(img, z, method=method))
                fh, fw = full.shape[:2]
                views = [(0, 0, min(fw, 40), min(fh, 30)), (0, 0, fw, fh)]
                if fw > 30 and fh > 20:
                    views.append((fw - 30, fh - 20, 30, 20))
                for (vx, vy, vw, vh) in views:
                    if vw <= 0 or vh <= 0 or vx + vw > fw or vy + vh > fh:
                        continue
                    total += 1
                    got, (ox, oy) = _viewport_render(base, plan, method,
                                                     vx, vy, vw, vh)
                    if got is None:
                        continue
                    ref = full[oy:oy + got.shape[0], ox:ox + got.shape[1]]
                    if got.shape != ref.shape or not np.array_equal(got, ref):
                        bad += 1
    check("视口渲染 == 整幅渲染 (%d 用例)" % total, bad == 0,
          "%d 处不一致" % bad)


def test_viewport_scales_with_zoom():
    """重绘耗时不应随倍率显著增长(核心性能回归测试)。"""
    rng = np.random.default_rng(1)
    img = Image.fromarray(
        rng.integers(0, 256, size=(1200, 1600, 3), dtype=np.uint8))
    VIEW = (1100, 700)

    def cost(z):
        plan = ns.plan_scale(img.width, img.height, z)
        base = img.crop(plan.crop_box) if plan.crop_box else img
        t0 = time.perf_counter()
        _viewport_render(base, plan, "block", 0, 0,
                         min(plan.dst_w, VIEW[0]), min(plan.dst_h, VIEW[1]))
        return time.perf_counter() - t0

    cost(2.0)                                   # 预热
    small = min(cost(2.0), cost(4.0))
    big = min(cost(8.0), cost(16.0))
    # 8~16 倍的耗时不应超过 2~4 倍太多(旧实现是 100 倍以上差距)
    ratio = big / max(small, 1e-9)
    check("视口渲染耗时与倍率基本无关", ratio < 6.0,
          "2-4x %.1fms vs 8-16x %.1fms, 比值 %.2f"
          % (small * 1000, big * 1000, ratio))


def main():
    tests = [
        test_quantize,
        test_plan,
        test_nosubpixel_property,
        test_exact_block_values,
        test_no_intermediate_colors,
        test_reject_interpolated,
        test_alpha_preserved,
        test_idempotent_zoom,
        test_unknown_method,
        test_dpi_module,
        test_tk_scaling_forced,
        test_screen_readback,
        test_viewport_equals_full,
        test_viewport_scales_with_zoom,
    ]
    for t in tests:
        try:
            t()
        except Exception:
            check("测试 %s 崩溃" % t.__name__, False,
                  traceback.format_exc().splitlines()[-1])

    passed = sum(1 for _, ok, _ in _results if ok)
    failed = [(n, d) for n, ok, d in _results if not ok]

    out = io.StringIO()
    out.write("=" * 62 + "\n")
    out.write("无亚像素引擎测试: %d / %d 通过\n" % (passed, len(_results)))
    out.write("=" * 62 + "\n")
    if failed:
        out.write("\n失败项:\n")
        for n, d in failed[:40]:
            out.write("  x %s\n      %s\n" % (n, d))
    else:
        out.write("\n全部通过。\n")
    sys.stdout.buffer.write(out.getvalue().encode("utf-8"))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
