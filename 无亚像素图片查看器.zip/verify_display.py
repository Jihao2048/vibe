# -*- coding: utf-8 -*-
"""
从屏幕帧缓冲直接读回像素, 验证"无亚像素"在显示链末端依然成立。

做法: 在画布上放一张已知的硬边图案(黑白相邻的单像素竖线),
然后用 Win32 的 BitBlt 从屏幕 DC 抓取同一区域, 逐点比对。
如果系统做了任何非整数倍缩放, 黑白之间必然出现灰色中间值。
"""
import ctypes, os, sys, tempfile
from ctypes import wintypes
import tkinter as tk
from PIL import Image

TMP = tempfile.mkdtemp(prefix="nosubpixel_")
PATTERN = os.path.join(TMP, "_dpi_pattern.png")
READBACK = os.path.join(TMP, "_dpi_readback.png")

import dpi_win
dpi_win.enable_dpi_awareness()

import viewer as V

u = ctypes.windll.user32
g = ctypes.windll.gdi32

class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long),
                ("biHeight", ctypes.c_long), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", ctypes.c_long),
                ("biYPelsPerMeter", ctypes.c_long), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]
class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]

def grab_screen(x, y, w, h):
    hdesktop = u.GetDC(0)
    mdc = g.CreateCompatibleDC(hdesktop)
    bmp = g.CreateCompatibleBitmap(hdesktop, w, h)
    g.SelectObject(mdc, bmp)
    SRCCOPY = 0x00CC0020
    g.BitBlt(mdc, 0, 0, w, h, hdesktop, x, y, SRCCOPY)
    bi = BITMAPINFO()
    bi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bi.bmiHeader.biWidth = w
    bi.bmiHeader.biHeight = -h
    bi.bmiHeader.biPlanes = 1
    bi.bmiHeader.biBitCount = 32
    bi.bmiHeader.biCompression = 0
    buf = ctypes.create_string_buffer(w * h * 4)
    g.GetDIBits(mdc, bmp, 0, h, buf, ctypes.byref(bi), 0)
    im = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB")
    g.DeleteObject(bmp); g.DeleteDC(mdc); u.ReleaseDC(0, hdesktop)
    return im

# 造一张 1px 竖条图案: 纯黑底 + 纯白单像素竖线, 间隔 1 像素
import numpy as np
W, H = 64, 40
a = np.zeros((H, W, 3), dtype=np.uint8)
a[:, ::2] = 255          # 每 2 列一根纯白 1px 竖线
img = Image.fromarray(a)
img.save(PATTERN)

app = V.NoSubpixelViewer()
app.geometry("700x300+120+120")
app.load(PATTERN)
app.zoom = 1.0
app.method = "block"
app.show_grid = False
app.compare = False
app.update(); app.update_idletasks()

result = {}

def measure():
    app.update_idletasks(); app.update()
    hwnd = app.winfo_id()
    # 可选: 把结论写入指定文件(沙箱下父进程无法用管道捕获输出)
    if "--result" in sys.argv:
        result_path = sys.argv[sys.argv.index("--result") + 1]
    else:
        result_path = None
    # 客户区左上角在屏幕上的位置
    pt = wintypes.POINT(0, 0)
    u.ClientToScreen(wintypes.HWND(app.winfo_id()), ctypes.byref(pt))
    x0, y0 = app._placed
    # 画布自身在客户区中的位置
    cx = app.canvas.winfo_rootx() - app.winfo_rootx()
    cy = app.canvas.winfo_rooty() - app.winfo_rooty()
    sx = pt.x + cx + x0
    sy = pt.y + cy + y0

    # 抓取整幅图案区域
    gw, gh = min(app._last_plan.dst_w, W), min(app._last_plan.dst_h, H)
    shot = grab_screen(sx, sy, gw, gh)
    shot.save(READBACK)

    arr = np.asarray(shot.convert("L")).astype(int)

    # 判据只依赖灰度级分布, 不依赖坐标是否精确对齐。
    # 图案本身只有 0 和 255 两种值; 只要系统做过任何插值,
    # 黑白交界处必然出现 0/255 之外的中间灰度。
    gray_mask = (arr > 8) & (arr < 247)
    n_gray = int(gray_mask.sum())
    uniq_gray = sorted(set(arr[gray_mask].flatten().tolist()))

    result["intermediate"] = n_gray
    result["uniq"] = uniq_gray[:10]
    result["shot_size"] = shot.size
    result["placed"] = (x0, y0)
    result["total"] = int(arr.size)

    print("屏幕缩放        : %d%%" % app.dpi_info["percent"])
    print("DPI 感知        : %s" % app.dpi_info["awareness"])
    print("tk scaling      : %.4f" % float(app.tk.call("tk", "scaling")))
    print("图像落点        : %s (必须是整数)" % (result["placed"],))
    print("抓取区域        : %s" % (result["shot_size"],))
    print("中间灰度像素数  : %d / %d" % (n_gray, arr.size))
    print("出现的灰度值    : %s" % (uniq_gray[:8],))
    print("")
    ok = (n_gray == 0)
    if ok:
        print("结论: 通过 —— 屏幕上读到的只有纯黑与纯白, 没有任何插值中间色。")
    else:
        print("结论: 失败 —— 出现了 %d 个中间灰度像素, 画面被重采样过。"
              % n_gray)
    if result_path:
        try:
            with open(result_path, "w", encoding="utf-8") as f:
                f.write("intermediate=%d total=%d ok=%s\n"
                        % (n_gray, arr.size, ok))
        except OSError:
            pass
    app.destroy()

app.after(900, measure)
app.mainloop()
sys.exit(0 if result.get("intermediate") == 0 else 1)
