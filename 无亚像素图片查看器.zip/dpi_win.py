# -*- coding: utf-8 -*-
"""
dpi_win.py -- 用 ctypes 直接控制 Windows 的 DPI 与物理像素映射

为什么需要这个模块
------------------
如果进程是"DPI 不感知"的, Windows 会把整个窗口先在 96 DPI 下渲染,
再用双线性插值整体放大到实际缩放比(例如 125%)。那一次插值会糊掉
所有像素 —— 不管上游算法多严格, 屏幕上出现的都已经是亚像素了。

本模块做三件事:
  1. 在创建任何窗口之前, 把进程声明为 Per-Monitor DPI Aware V2,
     让 Windows 不再替我们缩放。
  2. 查询当前显示器的真实缩放比(96 DPI = 100%, 120 DPI = 125%)。
  3. 提供一个"物理像素 <-> 客户区坐标"的映射, 使放置到画布上的图像
     能做到一个图像像素正好覆盖一个物理像素, 偏移取整到整数物理像素。

这样 Tk 的 1 个逻辑单位 = 1 个物理像素, 插值无从发生。
"""

from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes

__all__ = [
    "enable_dpi_awareness",
    "get_dpi",
    "get_scale",
    "make_physical",
    "physical_to_logical",
    "is_windows",
    "describe_environment",
]

is_windows = sys.platform.startswith("win")

# ---------------------------------------------------------------------------
# DPI 感知相关常量
# ---------------------------------------------------------------------------
DPI_AWARENESS_CONTEXT_UNAWARE = -1
DPI_AWARENESS_CONTEXT_SYSTEM_AWARE = -2
DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE = -3
DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = -4
DPI_AWARENESS_CONTEXT_UNAWARE_GDISCALED = -5

LOGPIXELSX = 88
MDT_EFFECTIVE_DPI = 0

_AWARENESS_STATE = {"done": False, "mode": "unset"}


def _user32():
    return ctypes.windll.user32


def _shcore():
    return ctypes.windll.shcore


def enable_dpi_awareness():
    """把当前进程声明为 DPI 感知。必须在创建 Tk 窗口之前调用。

    返回实际生效的模式名。按"最好 -> 次好"依次尝试。
    """
    if not is_windows:
        _AWARENESS_STATE.update(done=True, mode="non-windows")
        return "non-windows"

    if _AWARENESS_STATE["done"]:
        return _AWARENESS_STATE["mode"]

    u = _user32()
    mode = "none"

    # Windows 10 1703+: Per-Monitor V2
    try:
        fn = u.SetProcessDpiAwarenessContext
        fn.argtypes = [ctypes.c_void_p]
        fn.restype = wintypes.BOOL
        if fn(ctypes.c_void_p(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)):
            mode = "per-monitor-v2"
    except Exception:
        pass

    # Windows 8.1+: shcore
    if mode == "none":
        try:
            fn = _shcore().SetProcessDpiAwareness
            fn.argtypes = [ctypes.c_int]
            fn.restype = ctypes.c_long
            # 2 = PROCESS_PER_MONITOR_DPI_AWARE
            if fn(2) == 0:
                mode = "per-monitor"
        except Exception:
            pass

    # Vista+: 老式系统级 DPI 感知
    if mode == "none":
        try:
            if u.SetProcessDPIAware():
                mode = "system"
        except Exception:
            pass

    _AWARENESS_STATE.update(done=True, mode=mode)
    return mode


def get_dpi(hwnd=None):
    """返回当前显示器 DPI(96 = 100%)。"""
    if not is_windows:
        return 96

    u = _user32()

    # 优先用 GetDpiForWindow(能反映每显示器 DPI)
    if hwnd:
        try:
            v = u.GetDpiForWindow(wintypes.HWND(hwnd))
            if v:
                return int(v)
        except Exception:
            pass

    try:
        v = u.GetDpiForSystem()
        if v:
            return int(v)
    except Exception:
        pass

    hdc = u.GetDC(0)
    try:
        return int(ctypes.windll.gdi32.GetDeviceCaps(hdc, LOGPIXELSX))
    finally:
        u.ReleaseDC(0, hdc)


def get_scale(hwnd=None):
    """返回缩放比: 96 DPI -> 1.0, 120 DPI -> 1.25, 144 DPI -> 1.5。"""
    return get_dpi(hwnd) / 96.0


def make_physical(hwnd=None):
    """把进程设为"物理像素"语义。

    等价于告诉 Tk: 不要做任何 DPI 缩放, 1 个 Tk 单位就是 1 个物理像素。
    """
    enable_dpi_awareness()
    dpi = get_dpi(hwnd)
    return dpi / 96.0


def physical_to_logical(px, scale):
    """物理像素 -> 逻辑像素(用于需要与系统对话框一致的场合)。"""
    return px / scale if scale else px


def describe_environment(hwnd=None):
    """返回一份可读的环境描述, 便于在界面上如实告知用户。"""
    aware = enable_dpi_awareness()
    dpi = get_dpi(hwnd)
    scale = dpi / 96.0
    pct = round(scale * 100)
    ok = is_windows and aware in ("per-monitor-v2", "per-monitor", "system")
    if not is_windows:
        note = "非 Windows 平台, 不涉及系统 DPI 拉伸"
    elif ok:
        note = "已声明 DPI 感知, 系统不会再对画面做整体缩放"
    else:
        note = "警告: 未能声明 DPI 感知, 系统可能对画面做整体插值缩放"
    return {
        "platform": sys.platform,
        "awareness": aware,
        "dpi": dpi,
        "scale": scale,
        "percent": pct,
        "ok": ok,
        "note": note,
    }
