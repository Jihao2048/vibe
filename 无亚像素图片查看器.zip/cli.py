# -*- coding: utf-8 -*-
"""
cli.py -- 无亚像素图片处理命令行工具

示例
----
  # 放大 4 倍(整数倍)
  python cli.py in.png -o out.png -z 4

  # 缩小到 1/3, 整数块盒式平均
  python cli.py in.png -o out.png -z 0.3333

  # 最近邻方式, 并打印无亚像素自检报告
  python cli.py in.png -o out.png -z 2 -m nearest -v

  # 批量处理整个目录
  python cli.py ./photos -o ./out -z 0.5

  # 只做自检, 不输出文件
  python cli.py in.png --check-only
"""

from __future__ import annotations

import argparse
import os
import sys

from PIL import Image

import no_subpixel as ns

IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff",
              ".webp", ".ppm", ".pgm")


def _iter_images(path):
    if os.path.isfile(path):
        yield path
        return
    for name in sorted(os.listdir(path)):
        if name.lower().endswith(IMAGE_EXTS):
            yield os.path.join(path, name)


def _open(path):
    img = Image.open(path)
    img.load()
    if img.mode in ("P", "PA"):
        img = img.convert("RGBA" if "A" in img.mode else "RGB")
    if img.mode not in ("RGB", "RGBA", "L", "LA"):
        img = img.convert("RGB")
    return img


def process_one(src_path, out_path, zoom, method, verbose, check_only):
    img = _open(src_path)
    plan = ns.plan_scale(img.width, img.height, zoom)

    if check_only:
        out = ns.resize_no_subpixel(img, zoom, method=method)
        base = img.crop(plan.crop_box) if plan.crop_box else img
        rep = ns.check_no_subpixel(base, out, method=method)
        print("%s: %s" % (src_path, "通过" if rep["ok"] else "未通过"))
        if verbose or not rep["ok"]:
            print("   %s" % rep["reason"])
        return 0 if rep["ok"] else 1

    out = ns.resize_no_subpixel(img, zoom, method=method)
    base = img.crop(plan.crop_box) if plan.crop_box else img
    rep = ns.check_no_subpixel(base, out, method=method)

    out.save(out_path)
    print("%s  ->  %s" % (src_path, out_path))
    print("   源 %dx%d  输出 %dx%d  倍率 %.4fx (请求 %.4fx, 吸附自合法档位)"
          % (img.width, img.height, out.width, out.height,
             plan.effective_zoom, zoom))
    print("   方式: %s" % ("整数块盒式" if method == "block" else "最近邻"))
    if plan.cropped:
        print("   为凑整数块, 边缘裁切 %d 像素" % plan.cropped)
    print("   无亚像素自检: %s" % ("通过" if rep["ok"] else "未通过"))
    if verbose:
        print("   %s" % rep["reason"])
    return 0 if rep["ok"] else 1


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="无亚像素图片缩放工具: 输出中不存在插值出来的中间色。")
    ap.add_argument("input", help="输入图片或目录")
    ap.add_argument("-o", "--output", help="输出图片或目录")
    ap.add_argument("-z", "--zoom", type=float, default=1.0,
                    help="期望倍率, 会被吸附到最近的合法档位 (默认 1.0)")
    ap.add_argument("-m", "--method", choices=("block", "nearest"),
                    default="block",
                    help="block=整数块盒式(默认), nearest=最近邻")
    ap.add_argument("-v", "--verbose", action="store_true", help="输出详细信息")
    ap.add_argument("--check-only", action="store_true",
                    help="只做无亚像素自检, 不写文件")
    ap.add_argument("--list-zooms", action="store_true",
                    help="列出所有合法缩放倍率后退出")
    args = ap.parse_args(argv)

    if args.list_zooms:
        print("合法缩放倍率(只有这些档位才不会引入亚像素):")
        for z in ns.zoom_candidates(32):
            print("   %.6fx" % z)
        return 0

    if not os.path.exists(args.input):
        print("错误: 找不到 %s" % args.input, file=sys.stderr)
        return 2

    rc = 0
    files = list(_iter_images(args.input))
    if not files:
        print("错误: 没有可处理的图片", file=sys.stderr)
        return 2

    is_dir = os.path.isdir(args.input)
    if not args.check_only and not args.output:
        print("错误: 需要 -o/--output, 或使用 --check-only", file=sys.stderr)
        return 2

    if is_dir and not args.check_only:
        os.makedirs(args.output, exist_ok=True)

    for f in files:
        if args.check_only:
            dst = None
        elif is_dir:
            dst = os.path.join(args.output,
                               os.path.splitext(os.path.basename(f))[0] + ".png")
        else:
            dst = args.output
        try:
            rc |= process_one(f, dst, args.zoom, args.method,
                              args.verbose, args.check_only)
        except Exception as e:
            print("处理 %s 失败: %s" % (f, e), file=sys.stderr)
            rc = 1

    return rc


if __name__ == "__main__":
    sys.exit(main())
