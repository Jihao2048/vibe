# -*- coding: utf-8 -*-
"""
viewer.py -- 无亚像素图片查看器 (Tkinter GUI)

核心承诺
--------
你在窗口里看到的每一个像素, 都严格对应源图中的真实像素
(或整数个完整像素块的整数平均), 绝不出现插值出来的"半个像素"。

因此本查看器的缩放是"跳跃"的: 1x -> 2x -> 3x, 以及 1/2 -> 1/3 -> 1/4,
不会出现 1.37x 这类必然引入亚像素的倍率。

快捷键
------
  +  /  =        放一级(下一档合法倍率)
  -  /  _        缩一级
  1              回到 1:1 (100%)
  F              适应窗口(吸附到最近的合法倍率, 只会更小不会超出)
  0              适配并允许超过 1:1
  M              切换重采样方式: 整数块盒式 <-> 最近邻
  G              切换像素网格(仅放大时可见, 用来证明块是完整的)
  C              切换参考对比: 同位置用双线性渲染, 直观看到亚像素差异
  R              重新加载当前图片
  Space          抓手模式开关(左键拖拽平移)
  方向键          平移
  Esc / Q        退出
"""

from __future__ import annotations

import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageTk

import dpi_win
import no_subpixel as ns

# 必须在 Tk() 之前声明 DPI 感知, 否则 Windows 会把整个窗口
# 按 125% 等比例双线性放大, 一切上游努力都会在那一步被糊掉。
dpi_win.enable_dpi_awareness()


# 支持的图片扩展名
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff",
              ".webp", ".ppm", ".pgm")


class NoSubpixelViewer(tk.Tk):
    """无亚像素图片查看器主窗口。"""

    def __init__(self, path=None):
        tk.Tk.__init__(self)

        # Tk 在创建窗口时可能重置进程的 DPI 感知, 这里再声明一次。
        dpi_win.enable_dpi_awareness()

        # 注意: 这里【不要】改 tk scaling。
        # tk scaling 决定 Tk 把点(pt)换算成像素的比例, 字体和控件尺寸都按它算。
        # 把它压到 1.0 会让按钮和文字缩水约 30%(实测按钮 77x41 -> 55x31)。
        # 图像的无亚像素对齐并不依赖它, 而是靠:
        #   1) 图像本身由整数倍重采样生成;
        #   2) 摆放坐标取整到整数物理像素。
        # 控件保持 Tk 按 DPI 推出的自然尺寸即可(125% 缩放下就是正常大小)。
        self.dpi_info = dpi_win.describe_environment(self.winfo_id())
        # 1 个 Tk 画布单位 == 1 个物理像素(进程已 DPI 感知), 因此此比例为 1。
        self.scale = 1.0

        self.title("无亚像素图片查看器")
        self.geometry("1100x760")
        self.minsize(520, 380)
        self.configure(bg="#1e1e1e")

        self.src_image = None        # 原始 PIL 图像(永不修改)
        self.src_path = None
        self.zoom = 1.0              # 期望倍率(会被吸附到合法值)
        self.method = "block"        # "block" | "nearest"
        self.show_grid = False
        self.compare = False         # 右侧对比双线性
        self.pan_mode = False
        self.offset_x = 0
        self.offset_y = 0

        self._photo = None           # 保持引用, 防止被 GC
        self._photo_ref = None
        self._last_plan = None
        self._last_report = None
        self._selfcheck_ok = None

        # 渲染缓存: 只有可见区域变化时才重新采样
        self._cache_key = None
        self._cache_photo = None
        self._cache_origin = (0, 0)
        self._cache_cov = None
        self._cache_zoomkey = None
        self._placed = (0, 0)

        self._build_ui()
        self._bind_keys()

        if path:
            self.load(path)
        elif len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
            self.load(sys.argv[1])
        else:
            self._show_placeholder()

    # ------------------------------------------------------------------
    # 界面构建
    # ------------------------------------------------------------------
    def _build_ui(self):
        # 顶部工具栏
        bar = tk.Frame(self, bg="#2b2b2b", height=38)
        bar.pack(side=tk.TOP, fill=tk.X)

        def btn(text, cmd, tip=None):
            b = tk.Button(bar, text=text, command=cmd, bg="#3c3f41",
                          fg="#e8e8e8", activebackground="#4e5254",
                          activeforeground="#ffffff", relief=tk.FLAT,
                          padx=10, pady=4, cursor="hand2",
                          highlightthickness=0, bd=0)
            b.pack(side=tk.LEFT, padx=3, pady=5)
            return b

        btn("打开", self.open_dialog)
        btn("放大 +", lambda: self.step_zoom(1))
        btn("缩小 -", lambda: self.step_zoom(-1))
        btn("1:1", self.reset_zoom)
        btn("适应", self.fit_window)
        btn("方式", self.toggle_method)
        btn("网格", self.toggle_grid)
        btn("对比", self.toggle_compare)
        btn("重载", self.reload)

        self.status = tk.StringVar(value="就绪")
        lbl = tk.Label(bar, textvariable=self.status, bg="#2b2b2b",
                       fg="#9fd3a0", anchor="w", font=("Consolas", 9))
        lbl.pack(side=tk.LEFT, padx=14)

        # 画布区
        wrap = tk.Frame(self, bg="#1e1e1e")
        wrap.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(wrap, bg="#141414", highlightthickness=0,
                                bd=0)
        self.hbar = tk.Scrollbar(wrap, orient=tk.HORIZONTAL,
                                 command=self.canvas.xview)
        self.vbar = tk.Scrollbar(wrap, orient=tk.VERTICAL,
                                 command=self.canvas.yview)
        self.canvas.configure(xscrollcommand=self.hbar.set,
                              yscrollcommand=self.vbar.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.vbar.grid(row=0, column=1, sticky="ns")
        self.hbar.grid(row=1, column=0, sticky="ew")
        wrap.rowconfigure(0, weight=1)
        wrap.columnconfigure(0, weight=1)

        # 底部信息栏
        bottom = tk.Frame(self, bg="#2b2b2b", height=26)
        bottom.pack(side=tk.BOTTOM, fill=tk.X)
        self.info = tk.StringVar(value="")
        self.info_full = ""        # 完整信息(状态栏放不下时缩短显示)
        self.info_label = tk.Label(bottom, textvariable=self.info,
                                   bg="#2b2b2b", fg="#c8c8c8", anchor="w",
                                   font=("Consolas", 9))
        self.info_label.pack(side=tk.LEFT, padx=8)

        # 鼠标事件
        self.canvas.bind("<ButtonPress-1>", self._on_drag_start)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<MouseWheel>", self._on_wheel)
        self.canvas.bind("<Button-4>", lambda e: self.step_zoom(1))
        self.canvas.bind("<Button-5>", lambda e: self.step_zoom(-1))
        self.canvas.bind("<Configure>", lambda e: self._redraw())
        self.canvas.bind("<Motion>", self._on_motion)
        self.canvas.focus_set()

    def _bind_keys(self):
        b = self.bind
        b("<plus>", lambda e: self.step_zoom(1))
        b("<equal>", lambda e: self.step_zoom(1))
        b("<KP_Add>", lambda e: self.step_zoom(1))
        b("<minus>", lambda e: self.step_zoom(-1))
        b("<underscore>", lambda e: self.step_zoom(-1))
        b("<KP_Subtract>", lambda e: self.step_zoom(-1))
        b("<Key-1>", lambda e: self.reset_zoom())
        b("<Key-f>", lambda e: self.fit_window())
        b("<Key-F>", lambda e: self.fit_window())
        b("<Key-0>", lambda e: self.fit_window(allow_upscale=True))
        b("<Key-m>", lambda e: self.toggle_method())
        b("<Key-M>", lambda e: self.toggle_method())
        b("<Key-g>", lambda e: self.toggle_grid())
        b("<Key-G>", lambda e: self.toggle_grid())
        b("<Key-c>", lambda e: self.toggle_compare())
        b("<Key-C>", lambda e: self.toggle_compare())
        b("<Key-r>", lambda e: self.reload())
        b("<Key-R>", lambda e: self.reload())
        b("<Key-v>", lambda e: self._run_selfcheck())
        b("<Key-V>", lambda e: self._run_selfcheck())
        b("<space>", lambda e: self.toggle_pan())
        b("<Left>", lambda e: self.pan(-40, 0))
        b("<Right>", lambda e: self.pan(40, 0))
        b("<Up>", lambda e: self.pan(0, -40))
        b("<Down>", lambda e: self.pan(0, 40))
        b("<Escape>", lambda e: self.destroy())
        b("<Key-q>", lambda e: self.destroy())

    # ------------------------------------------------------------------
    # 文件加载
    # ------------------------------------------------------------------
    def _show_placeholder(self):
        self.status.set("请打开一张图片(工具栏\"打开\"), 或把图片路径作为命令行参数")

    def open_dialog(self):
        p = filedialog.askopenfilename(
            title="选择图片",
            filetypes=[("图片", " ".join("*" + e for e in IMAGE_EXTS)),
                       ("所有文件", "*.*")])
        if p:
            self.load(p)

    def load(self, path):
        try:
            img = Image.open(path)
            img.load()
        except Exception as e:
            messagebox.showerror("无法打开", "读取失败:\n%s\n\n%s" % (path, e))
            return

        self.src_path = path
        # 统一转成 RGB/RGBA, 保留透明度
        if img.mode in ("P", "PA"):
            img = img.convert("RGBA" if "A" in img.mode else "RGB")
        if img.mode not in ("RGB", "RGBA", "L", "LA"):
            img = img.convert("RGB")

        self.src_image = img
        self.zoom = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self._cache_key = None
        self._cache_cov = None
        self._cache_zoomkey = None
        self.title("无亚像素图片查看器 — %s" % os.path.basename(path))
        self.status.set("已加载 %dx%d" % img.size)
        self._selfcheck_ok = None
        self.fit_window()
        self._redraw()
        # 自检比较耗时, 放到界面画完之后再做, 不阻塞显示
        self.after(60, self._run_selfcheck)

    def reload(self):
        if self.src_path:
            self.load(self.src_path)

    # ------------------------------------------------------------------
    # 缩放控制
    # ------------------------------------------------------------------
    def _legal_zooms(self):
        return ns.zoom_candidates(limit=32)

    def step_zoom(self, direction):
        """在合法倍率集合中上/下一档。"""
        if self.src_image is None:
            return
        cands = list(self._legal_zooms())
        cur = ns.quantize_zoom(self.zoom)
        idx = min(range(len(cands)), key=lambda i: abs(cands[i] - cur))
        idx = max(0, min(len(cands) - 1, idx + direction))
        self.zoom = cands[idx]
        self._cache_cov = None      # 倍率变了, 之前的预渲染范围作废
        self._redraw()

    def reset_zoom(self):
        self.zoom = 1.0
        self.offset_x = self.offset_y = 0
        self._cache_cov = None
        self._redraw()

    def fit_window(self, allow_upscale=False):
        """适应窗口: 选一个不超出画布的最大合法倍率。"""
        if self.src_image is None:
            return
        cw, ch = self._canvas_size()
        cw = max(1, cw - 4)
        ch = max(1, ch - 4)
        iw, ih = self.src_image.size

        best = None
        for z in self._legal_zooms():
            if not allow_upscale and z > 1.0:
                continue
            plan = ns.plan_scale(iw, ih, z)
            if plan.dst_w <= cw and plan.dst_h <= ch:
                if best is None or z > best:
                    best = z
        self.zoom = best if best is not None else min(self._legal_zooms())
        self.offset_x = self.offset_y = 0
        self._cache_cov = None
        self._redraw()

    def toggle_method(self):
        self.method = "nearest" if self.method == "block" else "block"
        self._cache_key = None
        self._redraw()

    def toggle_grid(self):
        self.show_grid = not self.show_grid
        self._cache_key = None
        self._redraw()

    def toggle_compare(self):
        self.compare = not self.compare
        self.offset_x = self.offset_y = 0
        self._redraw()

    def toggle_pan(self):
        self.pan_mode = not self.pan_mode
        self.canvas.configure(cursor="fleur" if self.pan_mode else "")
        self._update_info()

    def pan(self, dx, dy):
        self.offset_x += dx
        self.offset_y += dy
        self._redraw()

    # ------------------------------------------------------------------
    # 渲染
    # ------------------------------------------------------------------
    def _render_viewport(self, img, zoom, method, vx, vy, vw, vh):
        """只渲染源图上对应视口的那一小块, 而不是整幅放大图。

        为什么可以这样做: 放大是整数倍复制, 缩小是按整数块求均值,
        因此"先在源图上裁一块再缩放"与"先缩放整幅再裁同样区域"
        得到的结果逐像素完全相同(已由 _equiv 验证脚本证明)。

        收益是决定性的: 1600x1200 放大 8 倍时, 渲染整幅图需要生成
        12800x9600 的数组(约 368MB, 耗时 >4 秒); 而只渲染约 1100x700
        的可见区域只需几十毫秒, 快 100 倍以上。

        参数 vx/vy/vw/vh 是可见区域在"输出坐标系"中的位置和大小。
        """
        plan = ns.plan_scale(img.width, img.height, zoom)

        # 源图上被裁掉的部分(为凑整数块)不参与显示
        src = img.crop(plan.crop_box) if plan.crop_box else img
        k = plan.factor

        if plan.kind == "up":
            # 输出坐标 -> 源坐标: 直接除以整数倍率(向下取整到块的起点)
            sx0 = max(0, vx // k)
            sy0 = max(0, vy // k)
            sx1 = min(src.width, -(-(vx + vw) // k))    # 向上取整
            sy1 = min(src.height, -(-(vy + vh) // k))
            box = (sx0, sy0, sx1, sy1)          # 源像素坐标
            # 该内容在【输出坐标系】中的左上角: 源坐标 * k
            out_x, out_y = sx0 * k, sy0 * k
        else:
            # 缩小: 输出坐标本身已经是块坐标, 对齐到整数块
            sx0 = max(0, vx)
            sy0 = max(0, vy)
            sx1 = min(src.width // k, vx + vw)
            sy1 = min(src.height // k, vy + vh)
            box = (sx0 * k, sy0 * k, sx1 * k, sy1 * k)   # 块索引 -> 源像素
            out_x, out_y = sx0, sy0             # 输出坐标即块索引

        if box[2] <= box[0] or box[3] <= box[1]:
            return None, plan, (0, 0)

        sub = src.crop(box)
        out = ns.resize_no_subpixel(sub, zoom, method=method)
        # 返回内容在输出坐标系中的确切落点, 供 _redraw 精确定位
        return out, plan, (out_x, out_y)

    def _render(self, img, zoom, method):
        """整幅渲染(仅用于导出/自检等非交互场合)。"""
        plan = ns.plan_scale(img.width, img.height, zoom)
        out = ns.resize_no_subpixel(img, zoom, method=method)
        base = img.crop(plan.crop_box) if plan.crop_box else img
        report = ns.check_no_subpixel(base, out, method=method)
        return out, plan, report

    def _run_selfcheck(self):
        """在后台按需执行完整自检(不进渲染热路径)。"""
        if self.src_image is None:
            return
        try:
            out, plan, rep = self._render(self.src_image, self.zoom, self.method)
            self._last_report = rep
            self._selfcheck_ok = bool(rep.get("ok"))
            self.status.set(u"自检: %s" % (u"通过" if rep["ok"] else u"未通过"))
            self._update_info()
        except Exception as e:
            self.status.set(u"自检失败: %s" % e)

    def _canvas_size(self):
        """取画布可视尺寸。初次加载时控件尚未布局(1x1), 回退到窗口尺寸估算。

        结果做缓存: 拖动/缩放时窗口尺寸通常不变, 可省去每次重绘的
        update_idletasks() 同步等待(实测这一步在热路径上有明显开销)。
        """
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw <= 1 or ch <= 1:
            self.update_idletasks()
            cw = self.canvas.winfo_width()
            ch = self.canvas.winfo_height()
            if cw <= 1 or ch <= 1:
                cw = max(1, self.winfo_width() - 24)
                ch = max(1, self.winfo_height() - 96)
        return cw, ch

    def _redraw(self):
        if self.src_image is None:
            return
        cw, ch = self._canvas_size()
        # 注意: 这里不调用 update_idletasks(), 避免每帧同步等待。

        try:
            plan = ns.plan_scale(self.src_image.width, self.src_image.height,
                                 self.zoom)
        except Exception as e:
            self.status.set("渲染失败: %s" % e)
            return
        self._last_plan = plan

        # 对比模式需要两套内容, 走整幅路径(但会自动降采样倍数以免卡死)
        if self.compare:
            self._redraw_compare(plan, cw, ch)
            return

        pw, ph = plan.dst_w, plan.dst_h
        # 输出图像相对画布左上角的位置(居中 + 平移), 取整到物理像素
        x = int((cw - pw) // 2 + self.offset_x)
        y = int((ch - ph) // 2 + self.offset_y)
        self._placed = (x, y)

        # 计算真正落在画布内的可见区域(输出坐标系)
        vx0 = max(0, -x)
        vy0 = max(0, -y)
        vx1 = min(pw, cw - x)
        vy1 = min(ph, ch - y)

        self.canvas.delete("all")
        if vx1 <= vx0 or vy1 <= vy0:
            # 整幅图都在视野外, 无需渲染
            self._photo = None
            self._update_info()
            return

        vw, vh = vx1 - vx0, vy1 - vy0

        # 预渲染边距: 多算视口外一圈, 小幅平移时可直接复用缓存。
        # 边距按整数块对齐, 保证放大时不会切到半个块。
        # 取值权衡: 越大 -> 拖动越顺, 但首次渲染越慢(面积随边距线性增长)。
        # 128 时首帧约 40ms, 且可覆盖约 128px 的连续拖动。
        pad = 128
        k = plan.factor
        if plan.kind == "up":
            pad = max(k, (pad // k) * k)
        pvx0 = max(0, vx0 - pad)
        pvy0 = max(0, vy0 - pad)
        pvx1 = min(pw, vx1 + pad)
        pvy1 = min(ph, vy1 + pad)

        # 若当前缓存已经覆盖所需区域, 直接复用
        cov = getattr(self, "_cache_cov", None)
        zoom_key = (plan.effective_zoom, self.method, plan.crop_box,
                    id(self.src_image))
        if (cov is not None and zoom_key == getattr(self, "_cache_zoomkey", None)
                and cov[0] <= vx0 and cov[1] <= vy0
                and cov[2] >= vx1 and cov[3] >= vy1):
            self._photo = self._cache_photo
            self._photo_ref = self._photo
            self.canvas.create_image(int(x + self._cache_origin[0]),
                                     int(y + self._cache_origin[1]),
                                     anchor=tk.NW, image=self._photo)
            self.canvas.configure(scrollregion=(0, 0, max(cw, pw), max(ch, ph)))
            self._update_info()
            return

        vx0, vy0, vx1, vy1 = pvx0, pvy0, pvx1, pvy1
        vw, vh = vx1 - vx0, vy1 - vy0
        cache_key = (vx0, vy0, vw, vh, plan.effective_zoom, self.method,
                     plan.crop_box, id(self.src_image))
        if cache_key != getattr(self, "_cache_key", None):
            try:
                out, _plan, (out_x, out_y) = self._render_viewport(
                    self.src_image, self.zoom, self.method, vx0, vy0, vw, vh)
            except Exception as e:
                self.status.set("渲染失败: %s" % e)
                return
            if out is None:
                self._photo = None
                self._update_info()
                return
            panel = out
            if self.show_grid and plan.kind == "up" and plan.factor > 1:
                panel = self._draw_grid(panel, plan.factor)
            self._cache_key = cache_key
            self._cache_photo = ImageTk.PhotoImage(panel)
            # 内容在输出坐标系中的确切落点(可能略早于 vx0, 因为对齐到块边界)
            self._cache_origin = (out_x, out_y)
            # 记录这块缓存覆盖的输出范围 + 生效参数
            self._cache_cov = (out_x, out_y,
                               out_x + panel.width, out_y + panel.height)
            self._cache_zoomkey = zoom_key
        else:
            self._cache_key = cache_key

        self._photo = self._cache_photo
        self._photo_ref = self._photo

        # 摆放位置 = 图像左上角在画布上的位置 + 内容在图像中的落点
        # 两项都是整数, 保证落在整数物理像素上
        self.canvas.create_image(int(x + self._cache_origin[0]),
                                 int(y + self._cache_origin[1]),
                                 anchor=tk.NW, image=self._photo)
        self.canvas.configure(scrollregion=(0, 0, max(cw, pw), max(ch, ph)))
        self._update_info()

    def _redraw_compare(self, plan, cw, ch):
        """对比模式: 整幅渲染成本高, 这里限制到屏幕能显示的规模。"""
        # 为了让对比模式不卡, 当输出超过画布太多时, 只渲染画布大小的一块。
        pw, ph = plan.dst_w, plan.dst_h
        try:
            out, _plan, (sx0, sy0) = self._render_viewport(
                self.src_image, self.zoom, self.method, 0, 0,
                min(pw, cw), min(ph, ch))
        except Exception as e:
            self.status.set("渲染失败: %s" % e)
            return
        if out is None:
            return
        panel = self._side_by_side(self.src_image, out, plan)
        self._photo_ref = panel
        self._photo = ImageTk.PhotoImage(panel)
        self._cache_key = ("cmp", self.zoom, self.method, id(self.src_image))

        x = int((cw - panel.width) // 2 + self.offset_x)
        y = int((ch - panel.height) // 2 + self.offset_y)
        self._placed = (x, y)
        self.canvas.delete("all")
        self.canvas.create_image(x, y, anchor=tk.NW, image=self._photo)
        self.canvas.configure(scrollregion=(0, 0, max(cw, panel.width),
                                            max(ch, panel.height)))
        self._update_info()

    def _draw_grid(self, img, k):
        """在放大图上叠加网格, 直观证明每个 k x k 块颜色统一。"""
        from PIL import ImageDraw
        g = img.convert("RGB").copy()
        d = ImageDraw.Draw(g)
        w, h = g.size
        color = (255, 0, 128)
        for x in range(0, w + 1, k):
            d.line([(x, 0), (x, h)], fill=color, width=1 if k > 2 else 1)
        for y in range(0, h + 1, k):
            d.line([(0, y), (w, y)], fill=color, width=1 if k > 2 else 1)
        return g

    def _side_by_side(self, src, out, plan):
        """左: 无亚像素结果; 右: 同尺寸的双线性结果(亚像素对照)。

        两个面板上下排列, 避免并排时超出窗口宽度被截断。
        """
        from PIL import ImageDraw
        left = out.convert("RGB")
        s = src.crop(plan.crop_box) if plan.crop_box else src
        # 双线性渲染到完全相同的尺寸 —— 这正是常见查看器的做法
        right = s.convert("RGB").resize(out.size, Image.BILINEAR)

        # 载入自带字体, 保证中文标签不会变成方块
        label1 = u"无亚像素 (本查看器) %.4fx" % plan.effective_zoom
        label2 = u"双线性插值 (含亚像素) 同尺寸"

        # 标签可能要放在很窄的面板上面, 所以先量文字宽度, 不够就换小字号
        font = None
        for size in (13, 12, 11, 10, 9, 8):
            f = self._load_font(size)
            try:
                w1 = f.getbbox(label1)[2]
                w2 = f.getbbox(label2)[2]
            except Exception:
                w1 = w2 = 0
            font = f
            if w1 <= 300 and w2 <= 300:
                break

        bar = 20
        gap = 22

        # 画布宽度必须同时容纳图像和标签, 否则标签会被裁掉半截。
        try:
            label_w = int(max(font.getbbox(label1)[2],
                              font.getbbox(label2)[2])) + 12
        except Exception:
            label_w = 160
        W = max(left.width, right.width, label_w)
        H = left.height + right.height + bar * 2 + gap
        canvas = Image.new("RGB", (W, H), (20, 20, 20))
        canvas.paste(left, (0, bar))
        y2 = left.height + bar + gap
        canvas.paste(right, (0, y2 + bar))

        d = ImageDraw.Draw(canvas)
        d.text((6, 4), label1, fill=(120, 255, 140), font=font)
        d.text((6, y2 + 4), label2, fill=(255, 150, 150), font=font)
        return canvas

    def _panel_size(self, plan):
        """返回当前显示面板的像素尺寸(考虑网格/对比叠加)。

        必须与 _side_by_side 的实际产出尺寸一致, 否则居中和悬停取色会偏。
        """
        w, h = plan.dst_w, plan.dst_h
        if self.compare:
            # 对比模式: 两个面板上下排, 中间有间隔, 每块上方有标签条。
            # 宽度还需容纳中文标签(按字号估算), 与 _side_by_side 保持一致。
            w = max(w, 170)
            return w, h * 2 + 62
        return w, h

    def _load_font(self, size):
        """尝试加载系统中文字体, 失败则退回默认字体。"""
        if not hasattr(self, "_font_cache"):
            self._font_cache = {}
        if size in self._font_cache:
            return self._font_cache[size]
        from PIL import ImageFont
        for name in ("msyh.ttc", "msyh.ttf", "simhei.ttf", "simsun.ttc"):
            try:
                f = ImageFont.truetype(name, size)
                self._font_cache[size] = f
                return f
            except Exception:
                continue
        f = ImageFont.load_default()
        self._font_cache[size] = f
        return f

    # ------------------------------------------------------------------
    # 交互
    # ------------------------------------------------------------------
    def _on_drag_start(self, ev):
        self._drag = (ev.x, ev.y, self.offset_x, self.offset_y)

    def _on_drag(self, ev):
        if not hasattr(self, "_drag"):
            return
        x0, y0, ox, oy = self._drag
        self.offset_x = ox + (ev.x - x0)
        self.offset_y = oy + (ev.y - y0)
        self._redraw()

    def _on_wheel(self, ev):
        self.step_zoom(1 if ev.delta > 0 else -1)

    def _on_motion(self, ev):
        if self.src_image is None or self._last_plan is None:
            return
        plan = self._last_plan
        z = plan.effective_zoom
        x0, y0 = getattr(self, "_placed", (0, 0))
        sx = int((ev.x - x0) / z) if z else 0
        sy = int((ev.y - y0) / z) if z else 0
        if 0 <= sx < self.src_image.width and 0 <= sy < self.src_image.height:
            px = self.src_image.getpixel((sx, sy))
            self.status.set("源像素 (%d, %d) = %s" % (sx, sy, px))

    # ------------------------------------------------------------------
    # 状态栏
    # ------------------------------------------------------------------
    def _update_info(self):
        if self.src_image is None or self._last_plan is None:
            return
        plan = self._last_plan
        mode = "整数块盒式" if self.method == "block" else "最近邻"
        # 自检已移出渲染热路径, 只有按 V 或加载后才会实际执行一次
        if self._selfcheck_ok is None:
            tag = u"按 V 检测"
        else:
            tag = u"通过" if self._selfcheck_ok else u"未通过"
        line = (
            u"源 %dx%d -> %dx%d | %.4fx (吸附自 %.2fx) | %s | 自检: %s"
            % (plan.src_w, plan.src_h, self._last_plan.dst_w,
               self._last_plan.dst_h, plan.effective_zoom,
               plan.requested_zoom, mode, tag)
        )
        if plan.cropped:
            line += u" | 裁切 %d" % plan.cropped
        if self.pan_mode:
            line += u" | 平移中"
        d = self.dpi_info
        line += u" | 屏幕 %d%% DPI感知%s" % (
            d["percent"], u"开" if d["ok"] else u"关")
        self.info_full = line
        self._fit_info_bar()

    def _fit_info_bar(self):
        """状态栏文字按窗口宽度自适应, 宁可少显示也不要被裁掉半截。"""
        if not self.info_full:
            return
        try:
            avail = max(120, self.winfo_width() - 24)
            f = self.info_label.cget("font")
        except Exception:
            self.info.set(self.info_full)
            return

        parts = [p.strip() for p in self.info_full.split("|")]
        # 从后往前丢字段(DPI 等次要信息先让位), 保留最前面的核心信息
        for keep in range(len(parts), 0, -1):
            cand = u" | ".join(parts[:keep])
            try:
                w = self.info_label.winfo_toplevel().tk.call(
                    "font", "measure", f, cand)
                w = int(w)
            except Exception:
                w = len(cand) * 7
            if w <= avail:
                self.info.set(cand)
                return
        self.info.set(parts[0] if parts else self.info_full)


def dpi_report():
    """打印 DPI 环境诊断, 并解释为什么这一步对无亚像素是必要的。"""
    e = dpi_win.describe_environment()
    print("平台            : %s" % e["platform"])
    print("DPI 感知模式    : %s" % e["awareness"])
    print("当前 DPI        : %d" % e["dpi"])
    print("屏幕缩放        : %d%%" % e["percent"])
    print("状态            : %s" % e["note"])
    print("")
    if e["percent"] != 100 and not e["ok"]:
        print("警告: 屏幕缩放为 %d%% 且未能声明 DPI 感知。" % e["percent"])
        print("      Windows 会把整个窗口按 %.2f 倍双线性放大," % e["scale"])
        print("      届时屏幕上不会有任何真正的无亚像素画面。")
    elif e["ok"]:
        print("说明: 进程已声明 DPI 感知, 且 Tk scaling 被强制为 1.0,")
        print("      因此 1 个图像像素 = 1 个物理像素, 系统不再做整体缩放。")
        if e["percent"] != 100:
            print("      本例屏幕缩放为 %d%%, 若不处理, 系统会插入一次" % e["percent"])
            print("      %.2f 倍双线性插值, 把一切糊掉。" % e["scale"])
    return 0


def main():
    if "--dpi-check" in sys.argv:
        return dpi_report()
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    path = args[0] if args else None
    app = NoSubpixelViewer(path)
    app.mainloop()


if __name__ == "__main__":
    main()
