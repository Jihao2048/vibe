# -*- coding: utf-8 -*-
"""生成一张分辨率测试卡, 并同时导出"无亚像素"与"双线性"放大对照图。"""
from PIL import Image, ImageDraw
import no_subpixel as ns

W, H = 180, 120
img = Image.new("RGB", (W, H), (16, 18, 26))
d = ImageDraw.Draw(img)

# 1. 单像素棋盘(检验是否出现中间灰)
for y in range(0, 24):
    for x in range(0, 24):
        if (x + y) % 2 == 0:
            d.point((x, y), fill=(255, 255, 255))

# 2. 1px 细线条组(最容易被插值糊掉)
for i in range(14):
    x = 30 + i * 4
    d.line([(x, 2), (x, 22)], fill=(255, 255, 255), width=1)

# 3. 同心圆(检验圆滑边缘是否出现台阶/亚像素环)
d.ellipse([100, 4, 172, 76], outline=(90, 220, 255), width=1)
d.ellipse([114, 18, 158, 62], outline=(255, 210, 60), width=1)

# 4. 硬边色块
d.rectangle([4, 34, 60, 70], fill=(220, 40, 60))
d.rectangle([64, 34, 120, 70], fill=(40, 200, 90))
d.rectangle([124, 34, 176, 70], fill=(60, 90, 230))

# 5. 斜线(检验锯齿)
for i in range(20):
    d.line([(2 + i * 2, 116), (2 + i * 2 + 20, 76)], fill=(255, 255, 255), width=1)

img.save("sample.png")
print("sample.png", img.size)

# 导出 4x 对照图: 左无亚像素 / 右双线性(裁剪一小块放大看差异)
box = (26, 0, 90, 26)          # 细线区域
crop = img.crop(box)
left = ns.resize_no_subpixel(crop, 6.0, method="block")
right = crop.resize((crop.width * 6, crop.height * 6), Image.BILINEAR)
cmb = Image.new("RGB", (left.width, left.height * 2 + 8), (10, 10, 10))
cmb.paste(left, (0, 0))
cmb.paste(right, (0, left.height + 8))
cmb.save("compare_zoom.png")
print("compare_zoom.png", cmb.size, "(上: 无亚像素 / 下: 双线性)")
